import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  TouchableOpacity
} from 'react-native';

export default function App() {
  const [time1, setTime1] = useState(0);
  const [time2, setTime2] = useState(0);

  function adicionarTime1() {
    if (time1 < 12) {
      setTime1(time1 + 1);
    }
  }

  function diminuirTime1() {
    if (time1 > 0) {
      setTime1(time1 - 1);
    }
  }

  function adicionarTime2() {
    if (time2 < 12) {
      setTime2(time2 + 1);
    }
  }

  function diminuirTime2() {
    if (time2 > 0) {
      setTime2(time2 - 1);
    }
  }

  function zerar() {
    setTime1(0);
    setTime2(0);
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <Text style={styles.titulo}>MARCADOR DE TRUCO</Text>

      <View style={styles.placar}>

        <View style={styles.card}>
          <Text style={styles.time}>TIME 1</Text>
          <Text style={styles.pontos}>{time1}</Text>

          <View style={styles.linha}>
            <TouchableOpacity
              style={styles.botao}
              onPress={diminuirTime1}
            >
              <Text style={styles.textoBotao}>-</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.botao}
              onPress={adicionarTime1}
            >
              <Text style={styles.textoBotao}>+</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.x}>X</Text>

        <View style={styles.card}>
          <Text style={styles.time}>TIME 2</Text>
          <Text style={styles.pontos}>{time2}</Text>

          <View style={styles.linha}>
            <TouchableOpacity
              style={styles.botao}
              onPress={diminuirTime2}
            >
              <Text style={styles.textoBotao}>-</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.botao}
              onPress={adicionarTime2}
            >
              <Text style={styles.textoBotao}>+</Text>
            </TouchableOpacity>
          </View>
        </View>

      </View>

      {time1 === 12 && (
        <Text style={styles.vitoria}>TIME 1 VENCEU!</Text>
      )}

      {time2 === 12 && (
        <Text style={styles.vitoria}>TIME 2 VENCEU!</Text>
      )}

      <TouchableOpacity
        style={styles.zerar}
        onPress={zerar}
      >
        <Text style={styles.textoZerar}>ZERAR PLACAR</Text>
      </TouchableOpacity>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E8C58A',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 40
  },

  placar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10
  },

  card: {
    backgroundColor: 'white',
    width: 145,
    padding: 20,
    borderRadius: 15,
    alignItems: 'center'
  },

  time: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333'
  },

  pontos: {
    fontSize: 65,
    fontWeight: 'bold',
    color: '#222',
    marginVertical: 10
  },

  x: {
    fontSize: 25,
    fontWeight: 'bold'
  },

  linha: {
    flexDirection: 'row',
    gap: 10
  },

  botao: {
    backgroundColor: '#333',
    width: 45,
    height: 45,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center'
  },

  textoBotao: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold'
  },

  vitoria: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#B00020',
    marginTop: 30
  },

  zerar: {
    backgroundColor: '#222',
    padding: 15,
    paddingHorizontal: 35,
    borderRadius: 10,
    marginTop: 25
  },

  textoZerar: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold'
  }
});